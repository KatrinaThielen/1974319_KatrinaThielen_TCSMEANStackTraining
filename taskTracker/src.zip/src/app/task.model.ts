// Class created to map JSON data
export class Task{
    constructor(public id:string,
        public name:string,
        public task:string,
        public deadline:string,
        public date:Date
        ){}
}
